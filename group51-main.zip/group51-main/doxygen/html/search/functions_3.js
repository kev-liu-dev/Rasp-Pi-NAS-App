var searchData=
[
  ['getuser_0',['getuser',['../user__db_8h.html#a1c04e1ac7a3ab5ebd000f8109a8ac089',1,'user_db.h']]]
];
