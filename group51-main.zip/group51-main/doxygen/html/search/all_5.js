var searchData=
[
  ['istextfile_0',['isTextFile',['../class_file_encryptor.html#a22ebdb64fce5423fece0aa3f66d0c914',1,'FileEncryptor']]]
];
