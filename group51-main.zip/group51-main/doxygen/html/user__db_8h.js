var user__db_8h =
[
    [ "json", "user__db_8h.html#ab701e3ac61a85b337ec5c1abaad6742d", null ],
    [ "getuser", "user__db_8h.html#a1c04e1ac7a3ab5ebd000f8109a8ac089", null ],
    [ "load_db", "user__db_8h.html#aff270f757be8f346f09872f81355e359", null ],
    [ "newuser", "user__db_8h.html#a9daaa1860ca587084c867b715a67b284", null ],
    [ "save_db", "user__db_8h.html#a4c2489fd98bb17cacdc294977f8866ab", null ],
    [ "DB_FILE", "user__db_8h.html#ab3c7d622d5666fe1f074606912c9e097", null ]
];