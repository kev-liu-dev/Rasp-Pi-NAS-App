var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "API_Server", "dir_da00ec7aaeedfe8616f4ae7c70e29392.html", "dir_da00ec7aaeedfe8616f4ae7c70e29392" ],
    [ "Database", "dir_e95107e76c1ba4922be3f343acf5dcf1.html", "dir_e95107e76c1ba4922be3f343acf5dcf1" ],
    [ "File", "dir_b9b4f4b00250c6904394903cddfd42b1.html", "dir_b9b4f4b00250c6904394903cddfd42b1" ]
];