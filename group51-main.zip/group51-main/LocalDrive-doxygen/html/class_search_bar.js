var class_search_bar =
[
    [ "SearchBar", "class_search_bar.html#a0ad58235edf9dac7e0512f08971205f3", null ]
];