var files_dup =
[
    [ "apiclient.h", "apiclient_8h_source.html", null ],
    [ "apiLogin.h", "api_login_8h_source.html", null ],
    [ "filecardwidget.h", "filecardwidget_8h_source.html", null ],
    [ "filehierarchyview.h", "filehierarchyview_8h_source.html", null ],
    [ "loginwindow.h", "loginwindow_8h_source.html", null ],
    [ "MainWindow.h", "_main_window_8h_source.html", null ],
    [ "searchbar.h", "searchbar_8h_source.html", null ],
    [ "sidebar.h", "sidebar_8h_source.html", null ],
    [ "toolbar.h", "toolbar_8h_source.html", null ]
];