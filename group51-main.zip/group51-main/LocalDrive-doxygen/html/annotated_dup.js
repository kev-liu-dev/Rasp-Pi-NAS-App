var annotated_dup =
[
    [ "APIClient", "class_a_p_i_client.html", "class_a_p_i_client" ],
    [ "FileCardWidget", "class_file_card_widget.html", "class_file_card_widget" ],
    [ "FileData", "struct_file_data.html", "struct_file_data" ],
    [ "FileHierarchyView", "class_file_hierarchy_view.html", "class_file_hierarchy_view" ],
    [ "LoginWindow", "class_login_window.html", "class_login_window" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "SearchBar", "class_search_bar.html", "class_search_bar" ],
    [ "Sidebar", "class_sidebar.html", "class_sidebar" ],
    [ "Toolbar", "class_toolbar.html", "class_toolbar" ]
];