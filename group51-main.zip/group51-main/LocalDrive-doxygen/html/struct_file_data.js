var struct_file_data =
[
    [ "dateModified", "struct_file_data.html#af6f27fbd81a300c30e4548d95b5c385a", null ],
    [ "extension", "struct_file_data.html#a0f5244f9e4919067ca68bb633c5748b9", null ],
    [ "fileName", "struct_file_data.html#a716118a4e4f384bafba7fa064ee0e854", null ],
    [ "iconName", "struct_file_data.html#aecfb3a7a9b74f2cef704efdd6e1fd078", null ],
    [ "isFavorite", "struct_file_data.html#a0b2c75e14ba9ca7d1d2e59d57c57fc2f", null ],
    [ "isSelected", "struct_file_data.html#a2ae9813be5eb6d93d4597472b592632d", null ]
];