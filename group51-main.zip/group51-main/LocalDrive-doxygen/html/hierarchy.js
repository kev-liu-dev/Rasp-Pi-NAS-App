var hierarchy =
[
    [ "APIClient", "class_a_p_i_client.html", null ],
    [ "FileData", "struct_file_data.html", null ],
    [ "QFrame", null, [
      [ "FileCardWidget", "class_file_card_widget.html", null ]
    ] ],
    [ "QLineEdit", null, [
      [ "SearchBar", "class_search_bar.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "LoginWindow", "class_login_window.html", null ],
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "FileHierarchyView", "class_file_hierarchy_view.html", null ],
      [ "Sidebar", "class_sidebar.html", null ],
      [ "Toolbar", "class_toolbar.html", null ]
    ] ]
];