var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "loadUserPreferences", "class_main_window.html#a0d428a17df466994fa0d2e9edc3e7c92", null ],
    [ "showWindow", "class_main_window.html#a04d901dec193f723d5ab3c4a3231b6b8", null ]
];