var searchData=
[
  ['deletefile_0',['deleteFile',['../class_a_p_i_client.html#a79028957051d5a5fe3807393170983d4',1,'APIClient']]],
  ['deleterequested_1',['deleteRequested',['../class_toolbar.html#ab000dbf805d2f69c6cd25652c2acd589',1,'Toolbar']]],
  ['downloadfile_2',['downloadFile',['../class_a_p_i_client.html#a245d9b0880cc14656265583c5b0f5368',1,'APIClient']]],
  ['downloadrequested_3',['downloadRequested',['../class_toolbar.html#a2061fd59018e2be7cd103a7eeb47b567',1,'Toolbar']]]
];
