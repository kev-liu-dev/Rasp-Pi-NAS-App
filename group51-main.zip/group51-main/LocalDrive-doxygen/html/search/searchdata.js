var indexSectionsWithContent =
{
  0: "acdefilmorstu~",
  1: "aflmst",
  2: "acdflmorstu~",
  3: "defi"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

