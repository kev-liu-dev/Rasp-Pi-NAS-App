var searchData=
[
  ['iconname_0',['iconName',['../struct_file_data.html#aecfb3a7a9b74f2cef704efdd6e1fd078',1,'FileData']]],
  ['isfavorite_1',['isFavorite',['../struct_file_data.html#a0b2c75e14ba9ca7d1d2e59d57c57fc2f',1,'FileData']]],
  ['isselected_2',['isSelected',['../struct_file_data.html#a2ae9813be5eb6d93d4597472b592632d',1,'FileData']]]
];
