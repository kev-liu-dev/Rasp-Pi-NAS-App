var searchData=
[
  ['datemodified_0',['dateModified',['../struct_file_data.html#af6f27fbd81a300c30e4548d95b5c385a',1,'FileData']]]
];
