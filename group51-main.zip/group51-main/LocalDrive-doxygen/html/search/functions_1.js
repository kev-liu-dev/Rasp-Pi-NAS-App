var searchData=
[
  ['categoryselected_0',['categorySelected',['../class_sidebar.html#a96fe460094c25ea7cdd91e8393d9f90e',1,'Sidebar']]]
];
