var searchData=
[
  ['extension_0',['extension',['../struct_file_data.html#a0f5244f9e4919067ca68bb633c5748b9',1,'FileData']]]
];
