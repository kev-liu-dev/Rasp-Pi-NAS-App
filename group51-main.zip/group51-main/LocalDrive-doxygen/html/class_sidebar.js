var class_sidebar =
[
    [ "Sidebar", "class_sidebar.html#a874f7f7907a44517ee9cf9ac2c1888d7", null ],
    [ "categorySelected", "class_sidebar.html#a96fe460094c25ea7cdd91e8393d9f90e", null ]
];