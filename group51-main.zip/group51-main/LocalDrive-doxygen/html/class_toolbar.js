var class_toolbar =
[
    [ "Toolbar", "class_toolbar.html#a0de2d55d4beb1807858a62e35aecd543", null ],
    [ "deleteRequested", "class_toolbar.html#ab000dbf805d2f69c6cd25652c2acd589", null ],
    [ "downloadRequested", "class_toolbar.html#a2061fd59018e2be7cd103a7eeb47b567", null ],
    [ "onSelectionInfoChanged", "class_toolbar.html#a2bc1b98b03842bc9f821260988ed82ed", null ],
    [ "renameRequested", "class_toolbar.html#a67780024e9dbfc6408d82336454ccf4f", null ],
    [ "selectAllToggled", "class_toolbar.html#a8b94412e7c47b49586259eb30a744de0", null ],
    [ "sortRequested", "class_toolbar.html#af52a0a7bada3e1d084c14af0cf4b7630", null ],
    [ "uploadRequested", "class_toolbar.html#a2887c37d53f7772d082db0b5fdf8b41a", null ]
];