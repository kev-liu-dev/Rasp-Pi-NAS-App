var class_file_card_widget =
[
    [ "FileCardWidget", "class_file_card_widget.html#a65bd7f1cde334cf5e749228e705bcec6", null ],
    [ "favoriteToggled", "class_file_card_widget.html#ad443e8fbfd7e267267b23b27f1be4ac3", null ],
    [ "selectedToggled", "class_file_card_widget.html#a2fbc2ef8e1a9b089cca0612734700d1c", null ]
];